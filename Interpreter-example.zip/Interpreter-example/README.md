# Interpreter
Interpreter project for EECS 345: Programming Language Concepts.

This is an interpreter for a very simple Java/C-ish language. The language has variables, assignment statements, mathematical expressions, comparison operators, boolean operators, if statements, while statements, and return statements.

An example program is as follows:
```
var x = 14;
var y = 3 * x - 7;
function gcd(a,b) {
  if (a < b) {
    var temp = a;
    a = b;
    b = temp;
  }
  var r = a % b;
  while (r != 0) {
    a = b;
    b = r;
    r = a % b;
  }
  return b;
}
function main () {
  return gcd(x,y);
}
```

## Usage
Inside [interpreter.rkt](interpreter.rkt), type
```
(interpret filename)
```
where `filename` contains the program to interpret.

## Tasks
### Done
### Ongoing
### Todo
* Change the interpret function to take class
* Change Mstate and Mvalue to expect class



## Contributors
* [Hung Vu](https://github.com/duchungvu) ([hdv4](mailto:hdv4@case.edu))
* [Hieu Pham](https://github.com/HieuPham9720) ([hmp43](mailto:hmp43@case.edu))
